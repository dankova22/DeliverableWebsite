#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun  8 18:38:11 2021

@author: dankovacevich
"""
print(junk