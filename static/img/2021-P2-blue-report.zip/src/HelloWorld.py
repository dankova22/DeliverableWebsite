#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May 27 17:17:30 2021

@author: dankovacevich
"""
print('Hello World!')