#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May 27 18:48:38 2021

@author: dankovacevich
"""
print('Hello World'